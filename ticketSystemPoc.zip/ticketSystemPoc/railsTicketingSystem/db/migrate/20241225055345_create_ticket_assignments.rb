class CreateTicketAssignments < ActiveRecord::Migration[8.0]
  def change
    create_table :ticket_assignments do |t|
      t.references :ticket, null: false, foreign_key: true
      t.references :user, null: false, foreign_key: true

      t.timestamps
    end

    add_index :ticket_assignments, %i[ticket_id user_id], unique: true
  end
end

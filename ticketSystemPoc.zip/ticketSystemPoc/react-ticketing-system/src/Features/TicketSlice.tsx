import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import { Navigate } from "react-router-dom";
import { apiUrl } from "../Components/Utils";
import { authToken } from "../Components/Utils";
import axios from 'axios';

// Add ticket
export const addTicket = createAsyncThunk('AddTicket', async (formData, {rejectWithValue})=>{
  try {
    const response = await axios.post(`${apiUrl}/tickets`, formData, {
      headers: {
        Authorization: `Bearer ${authToken}`,
        'Content-Type': 'multipart/form-data',
      },
    });

    return response; 
  } catch (error: any) {
    if(error.response) {
      return rejectWithValue(error.response);
    } else {
      return rejectWithValue(error);
    }
  }
});

// all tickets
export const fetchTickets = createAsyncThunk('FetchTickets', async (_, { rejectWithValue })=>{
  try {
    const response = await axios.get(`${apiUrl}/tickets`, {
        headers: {
          Authorization: `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
    });

    return response;
  } catch (error: any) {
    if(error.response) {
      return rejectWithValue(error.response);
    } else {
      return rejectWithValue(error);
    }
  }
});

// Delete ticket
export const deleteTicket = createAsyncThunk('DeleteTicket', async (id, {rejectWithValue}) => {
  try {
    await axios.delete(`${apiUrl}/tickets/${id}`, {
        headers: {
          Authorization: `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
    });

    return id;
  } catch (error: any) {
    if(error.response) {
      return rejectWithValue(error.response);
    } else {
      return rejectWithValue(error);
    }
  }
});

// View ticket
export const viewTicket = createAsyncThunk('ViewTicket', async (id, {rejectWithValue}) => {
  try {
    const response = await axios.get(`${apiUrl}/tickets/${id}`, {
        headers: {
          Authorization: `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
    });

    return response;
  } catch (error: any) {
    if(error.response) {
      return rejectWithValue(error.response);
    } else {
      return rejectWithValue(error);
    }
  }
});

// Update ticket
export const updateTicket = createAsyncThunk('UpdateTicket', async (formData, {rejectWithValue}) => {
  try {
    const response = await axios.patch(`${apiUrl}/tickets/${formData.id}`, formData, {
      headers: {
        Authorization: `Bearer ${authToken}`,
        'Content-Type': 'multipart/form-data',
      },
    });

    return response; 
  } catch (error: any) {
    if(error.response) {
      return rejectWithValue(error.response);
    } else {
      return rejectWithValue(error);
    }
  }
});

const ticketSlice = createSlice({
  name: 'tickets',
  initialState: {
    tickets: [],
    ticket: {},
    status: 'idle',
    error: null 
  },
  reducers: {},
  extraReducers: (bundler) => {
    // Create Ticket
    bundler.addCase(addTicket.fulfilled, (state, action) => {
      state.status = 'succeeded';
      if(action.payload.status == 201) {
        toast.success('Your Ticket created successfully!');
        setTimeout(() => {
          window.location.href = '/';
        }, 2000);
      }
    }).addCase(addTicket.pending, (state, _) => {
      state.status = 'loading'
    }).addCase(addTicket.rejected, (state, action) => {
      state.status = 'failed';
      toast.error(action.payload.data.error);
      setTimeout(() => {
        <Navigate to="/"/>
      }, 2000);
    });

    // Ticket list
    bundler.addCase(fetchTickets.fulfilled, (state, action) => {
      state.status = 'succeeded';
      state.tickets = action.payload.data;
    }).addCase(fetchTickets.pending, (state, _) => {
      state.status = 'pending';
    }).addCase(fetchTickets.rejected, (state, action) => {
      state.status = 'failed';
      toast.error(action.payload.data.error);
      setTimeout(() => {
        window.location.href = '/sign-in';
      }, 2000);
    });

    // Update ticket
    bundler.addCase(updateTicket.fulfilled, (state, action) => {
      state.status = 'succeeded';
      if(action.payload.status == 200) {
        toast.success('Your Ticket updated successfully!');
        setTimeout(() => {
          window.location.href = '/tickets';
        }, 2000);
      }
    })

    // View/ Edit Ticket
    bundler.addCase(viewTicket.fulfilled, (state: any, action: any) => {
      state.status = 'succeeded'
      state.ticket = action.payload.data;
    });

    // Delete Ticket
    bundler.addCase(deleteTicket.fulfilled, (state: any, action: any) => {
      toast.info('Your ticket deleted successfully!');
      state.tickets = state.tickets.filter((ticket: {}) => ticket.id !== action.payload);
    });
  }
});
export const selectTickets = (state: any) => state.tickets.tickets;
export const selectTicket = (state: any) => state.tickets.ticket;
export const selectStatus = (state: any) => state.tickets.status;
export const selectError = (state: any) => state.tickets.error;

export default ticketSlice.reducer;


module Api
  module V1
    class TicketsController < ApplicationController
      before_action :authorize_request

      def create
        service = TicketService.new(params)
        ticket = service.create_ticket

        render json: ticket, status: :created
      rescue => e
        render json: { error: e.message }, status: :unprocessable_entity
      end

      def update
        service = TicketService.new(params)
        ticket = service.update_ticket

        render json: ticket, status: 200
      rescue => e
        render json: { error: e.message }, status: :unprocessable_entity
      end

      def show
        ticket = Ticket.find(params[:id])

        render json: ticket
      end

      def destroy
        ticket = Ticket.find(params[:id])
        ticket.destroy!

        render json: { status: "200", message: "Ticket destroyed" }
      rescue => e
        render json: { error: e.message }
      end

      def index
        tickets = Ticket.all

        render json: tickets
      end
    end
  end
end

user = User.create!(name: Faker::Name.name, username: 'abc', email: 'abc@gmail.com', password: '123456', password_confirmation: '123456')

5.times do 
  Ticket.create!(title: Faker::Name.name, description: Faker::Address.city, status: rand(3), user: user)
end

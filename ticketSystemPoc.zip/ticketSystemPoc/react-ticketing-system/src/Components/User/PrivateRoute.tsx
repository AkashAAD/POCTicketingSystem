import { Navigate } from 'react-router-dom';
import { authToken } from '../Utils';

const PrivateRoute = ({children}) => {
  return authToken ? children : <Navigate to="/sign-in"/>;
};

export default PrivateRoute;

import Banner from '../../assets/ticketing-system.webp';

const Home = () => {
  return(
    <>
      <div className=''>
        <img src={`${Banner}`} alt="" />
      </div>
    </>
  )
};

export default Home;
class CreateTicketComments < ActiveRecord::Migration[8.0]
  def change
    create_table :ticket_comments do |t|
      t.text :content, null: false
      t.references :user, null: false, foreign_key: true
      t.references :ticket, null: false, foreign_key: true

      t.timestamps
    end

    add_index :ticket_comments, %i[user_id ticket_id]
  end
end

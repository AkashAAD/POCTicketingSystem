import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { PencilIcon, TrashIcon, EyeIcon } from "@heroicons/react/24/solid";
import { stringFormat } from '../Utils';
import { useNavigate } from 'react-router-dom';
import { fetchTickets, deleteTicket, selectTickets, selectStatus, selectError } from '../../Features/TicketSlice';

const Tickets = () => {
  const navigate = useNavigate();
  const dispatchTickets: any = useDispatch();
  const tickets = useSelector(selectTickets);
  const status = useSelector(selectStatus);
  const error = useSelector(selectError);

  useEffect(() => {
    if(status === 'idle') {
      dispatchTickets(fetchTickets());
    }
  }, [status, dispatchTickets]);

  const handleDeleteTicket = (id: number) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this ticket?");

    if (confirmDelete) {
      dispatchTickets(deleteTicket(id));
    }
  };

  const handleViewTicket = (id: number) => {
    navigate(`/ticket/${id}/show`);
  }

  const handleEditTicket = (id: number) => {
    navigate(`/ticket/${id}/edit`);
  }

  return(
    <>
      <div className="justify-items-center h-screen overflow-x-auto container">
        <h2 className='text-4xl font-bold dark:text-black'>Your Tickets</h2>
        {status === 'loading' && <p>Loading...</p>}
        {error && <p>Error: {error}</p>}
        <table className="w-max text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" className="px-6 py-3">
                    Title
                </th>
                <th scope="col" className="px-6 py-3">
                    Description
                </th>
                <th scope="col" className="px-6 py-3">
                    Priority
                </th>
                <th scope="col" className="px-6 py-3">
                    Status
                </th>
                <th scope="col" className="px-6 py-3">
                  #
                </th>
              </tr>
            </thead>
            <tbody>
              {
                status === 'succeeded' && tickets.length > 0 ? (
                tickets.map((ticket: any) => (
                  <tr key={ticket.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                      {ticket.title}
                    </td>
                    <td className="px-6 py-4">{ticket.description}</td>
                    <td className="px-6 py-4">{stringFormat(ticket.priority)}</td>
                    <td className="px-6 py-4">{stringFormat(ticket.status)}</td>
                    <td className="px-6 py-4">
                      <div className="flex space-x-4">
                        <button onClick={() => { handleEditTicket(ticket.id) }} className="text-blue-500 hover:text-blue-700">
                          <PencilIcon className="h-6 w-6" />
                        </button>

                        <button onClick={() => { handleViewTicket(ticket.id) }} className="text-green-500 hover:text-green-700">
                          <EyeIcon className="h-6 w-6" />
                        </button>

                        <button onClick={() => { handleDeleteTicket(ticket.id) }} className="text-red-500 hover:text-red-700">
                          <TrashIcon className="h-6 w-6" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center">No tickets available</td>
                </tr>
              )}
            </tbody>
        </table>
      </div>
    </>
  )
};

export default Tickets;
const Page404 = () => {
  return(
  <div className="flex items-center justify-center h-svh">
    <div className="box-border h-800 w-800 p-4">
      <h1>Page Not Found</h1>
    </div>
  </div>
  );
}

export default Page404;

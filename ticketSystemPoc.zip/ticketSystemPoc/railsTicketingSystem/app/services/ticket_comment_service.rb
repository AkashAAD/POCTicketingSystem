class TicketCommentService < TicketBaseService
  def initialize(comment_params)
    @comment_params = comment_params
  end

  def add_comment
    @comment_params = @comment_params.merge(ticket: ticket(@comment_params[:ticket_id]), user: Current.user)
    comment = TicketComment.new(@comment_params)

    comment.save!

    comment
  end

  def ticket_comments
    ticket(@comment_params[:ticket_id]).ticket_comments
  end
end

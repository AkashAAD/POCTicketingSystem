import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
// import { Navigate } from "react-router-dom";
import { toast } from "react-toastify";
import { apiUrl } from "../Components/Utils";
import axios from 'axios';

export const signIn = createAsyncThunk('signIn', async (formData, {rejectWithValue})=>{
  try {
    const response = await axios.post(`${apiUrl}/user/login`, formData);
    return response;
  } catch (error: any) {
    if(error.response) {
      return rejectWithValue(error.response);
    } else {
      return rejectWithValue(error);
    }
  }
});

const userSlice = createSlice({
  name: 'user',
  initialState: {
    status: 'idle',
    error: null 
  },
  reducers: {},
  extraReducers: (bundler) => {
    bundler
      .addCase(signIn.fulfilled, (_, action) => {
        toast.success('You are logged in successfully!');
        localStorage.setItem('authToken', action.payload.data.token);

        setTimeout(() => {
          window.location.href = '/';
        }, 1000);
      }).addCase(signIn.pending, (_, action) => {
        // state.status = 'succeeded';
        // state.items = action.payload;
      }).addCase(signIn.rejected, (_, action) => {
        toast.error(action.payload.data.error);
      });
  }
});

export default userSlice.reducer;


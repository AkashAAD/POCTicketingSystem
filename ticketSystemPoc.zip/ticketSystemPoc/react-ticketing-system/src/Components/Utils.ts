export const authToken = localStorage.getItem('authToken');
export const isAuthenticated = authToken ? true : false
export const apiUrl = import.meta.env.VITE_API_URL;
export const stringFormat = (str: string) => str && str.replace(/_/g, ' ').replace(/\b\w/g, (char: string) => char.toUpperCase())

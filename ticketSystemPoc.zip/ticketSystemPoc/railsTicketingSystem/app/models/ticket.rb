class Ticket < ApplicationRecord
  belongs_to :user
  has_many :ticket_comments, dependent: :destroy
  has_many :ticket_assignments
  has_many :assigned_users, through: :ticket_assignments, source: :user
  has_many :ticket_status_histories

  validates :title, presence: true

  enum :priority, %i[low medium high critical]
  enum :status, %i[open in_progress closed]
end

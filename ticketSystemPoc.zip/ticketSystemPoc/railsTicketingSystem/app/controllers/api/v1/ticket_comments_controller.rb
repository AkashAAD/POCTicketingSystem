module Api
  module V1
    class TicketCommentsController < ApplicationController
      before_action :authorize_request

      def create
        service = TicketCommentService.new(comment_params)
        comment = service.add_comment

        render json: comment, status: :created
      rescue => e
        render json: { error: e.message }, status: :unprocessable_entity
      end
    
      def comments
        service = TicketCommentService.new(params)
        comments = service.ticket_comments
        
        render json: comments, status: :ok
      rescue => e
        render json: { error: e.message }, status: :unprocessable_entity
      end
    
      private
    
      def comment_params
        params.require(:ticket_comment).permit(:content, :ticket_id)
      end
    end
  end
end

import { isAuthenticated } from "../Utils";

const SignUp = () => {
  if(isAuthenticated) {
    window.location.href = '/';
  }

  return(
    <>
      <h1>SignUp</h1>
    </>
  )
}

export default SignUp;

import { useReducer, useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addTicket, updateTicket, viewTicket, selectTicket } from '../../Features/TicketSlice';
import { useParams } from 'react-router-dom';

// Priorities
const priorityOptions = [
  { value: '', label: '-Select Priority-' },
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
  { value: 'critical', label: 'Critical' },
];

// Reducer function
const formReducer = (state: any, action: any) => {
  switch (action.type) {
    case 'UPDATE_FIELD':
      return {
        ...state,
        formData: { ...state.formData, ticket: { ...state.formData.ticket, [action.field]: action.value } },
        formErrors: { ...state.formErrors, [action.field]: action.error || '' },
      };
    case 'SET_ERRORS':
      return { ...state, formErrors: action.errors };
    case 'SET_SUBMITTED':
      return { ...state, isSubmitted: action.value };
    default:
      return state;
  }
};

// Validation function for individual fields
const validateField = (field: any, value: any) => {
  switch (field) {
    case 'title':
      return value.trim() ? '' : 'Title is required.';
    case 'description':
      return value.trim() ? '' : 'Description is required.';
      case 'priority':
        return value.trim() ? '' : 'Priority is required.';
      default:
      return '';
  }
};

// Form component
const Ticket = () => {
  // Initial state for the reducer
  const initialState = {
    formData: {
      ticket: {
        title: '',
        description: '',
        priority: ''
      }
    },
    formErrors: {},
    isSubmitted: false,
  };
  const { id } = useParams();
  const dispatchTickets: any = useDispatch();
  const ticket = id ? useSelector(selectTicket) : undefined;
  const [state, dispatch] = useReducer(formReducer, initialState);
  const dispatchTicket: any = useDispatch();

  useEffect(() => {
    if (id) {
      dispatchTickets(viewTicket(id));
    }
  }, [dispatchTickets, id]);

  useEffect(() => {
    if(ticket) {
      state.formData.ticket = {
        title: ticket.title || '',
        description: ticket.description || '',
        priority: ticket.priority || ''
      }
    }
  }, [ticket]);

  const handleChange = useCallback(
    (e: any) => {
      const { name, value } = e.target;
      const error = validateField(name, value);
      dispatch({ type: 'UPDATE_FIELD', field: name, value, error });
    },
    []
  );

  const handleSubmit = (e: any) => {
    e.preventDefault();

    const errors: any = {};
    for (const field in state.formData.ticket) {
      const error = validateField(field, state.formData.ticket[field]);
      if (error) errors[field] = error;
    }

    dispatch({ type: 'SET_ERRORS', errors });

    if (Object.keys(errors).length === 0) {
      dispatch({ type: 'SET_SUBMITTED', value: true });

      if(id) {
        state.formData.id = id
        dispatchTicket(updateTicket(id, state.formData));
      } else {
        dispatchTicket(addTicket(state.formData));
      }
    }
  };

  return (
    <>
      <div className='text-center pt-3'>
        <h2 className='text-4xl font-bold dark:text-black'>Create your ticket from here:</h2>
        <form className="max-w-sm mx-auto" onSubmit={handleSubmit} noValidate>
          <label className='text-xl text-gray-900 block mb-2 text-sm font-large text-gray-900 text-left' htmlFor="title">Title:</label>
          <input
            id="title"
            name="title"
            type="text"
            value={ state.formData.ticket.title || '' }
            onChange={ handleChange }
            className="text-sm rounded-lg block w-full p-2.5 dark:focus:ring-blue-500 border-solid border-2 border-sky-500"
            placeholder=""
          />
          {(state.formErrors.title || '') && <div className='text-left' style={{ color: 'red' }}>{(state.formErrors.title || '')}</div>}
          <br />

          <label className='text-xl text-gray-900 block mb-2 text-sm font-large text-gray-900 text-left' htmlFor="description">Description:</label>
          <textarea
            id="description"
            name="description"
            value={state.formData.ticket.description || ''}
            onChange={handleChange}
            className="text-sm rounded-lg block w-full p-2.5 dark:focus:ring-blue-500 border-solid border-2 border-sky-500"
            placeholder=""
          />
          {(state.formErrors.description || '') && <div className='text-left' style={{ color: 'red' }}>{(state.formErrors.description || '')}</div>}
          <br />
          <label className='text-xl text-gray-900 block mb-2 text-sm font-large text-gray-900 text-left' htmlFor="priority">Priority:</label>
          <select
            id="priority"
            name="priority"
            value={state.formData.ticket.priority || ''}
            onChange={handleChange}
            className="text-sm rounded-lg block w-full p-2.5 dark:focus:ring-blue-500 border-solid border-2 border-sky-500"
          >
            {priorityOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          {(state.formErrors.priority || '') && <div className='text-left' style={{ color: 'red' }}>{(state.formErrors.priority || '')}</div>}
          <br />

          <button type="submit" className="float-left text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Submit</button>
        </form>
      </div>    
    </>
  );
};

export default Ticket;

import { useReducer, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { isAuthenticated } from '../Utils';
import { signIn } from '../../Features/UserSlice';

const initialState = {
  formData: {
    email: '',
    password: ''
  },
  formErrors: {},
  isSubmitted: false,
};

const formReducer = (state: any, action: any) => {
  switch (action.type) {
    case 'UPDATE_FIELD':
      return {
        ...state,
        formData: { ...state.formData, [action.field]: action.value },
        formErrors: { ...state.formErrors, [action.field]: action.error || '' },
      };
    case 'SET_ERRORS':
      return { ...state, formErrors: action.errors };
    case 'SET_SUBMITTED':
      return { ...state, isSubmitted: action.value };
    default:
      return state;
  }
};

// Validation function for individual fields
const validateField = (field: any, value: any) => {
  switch (field) {
    case 'email':
      return value.trim() ? '' : 'Email is required.';
    case 'password':
      return value.trim() ? '' : 'Password is required.';
    default:
      return '';
  }
};

// Form component
const SignIn = () => {
  if(isAuthenticated) {
    return window.location.href = '/';
  }

  const [state, dispatch] = useReducer(formReducer, initialState);
  const dispatchTicket = useDispatch();

  const handleChange = useCallback(
    (e: any) => {
      const { name, value } = e.target;
      const error = validateField(name, value);
      dispatch({ type: 'UPDATE_FIELD', field: name, value, error });
    },
    []
  );

  const submitSignInForm = (e: any) => {
    e.preventDefault();

    const errors: any = {};
    for (const field in state.formData) {
      const error = validateField(field, state.formData[field]);
      if (error) errors[field] = error;
    }

    dispatch({ type: 'SET_ERRORS', errors });

    if (Object.keys(errors).length === 0) {
      dispatch({ type: 'SET_SUBMITTED', value: true });
      dispatchTicket(signIn(state.formData));
    }
  };

  return (
    <div className='text-center pt-3'>
      <h2 className='text-4xl font-bold dark:text-black'>Sign in from here:</h2>
      <form className="max-w-sm mx-auto" onSubmit={submitSignInForm} noValidate>
        <label className='text-xl text-gray-900 block mb-2 text-sm font-large text-gray-900 text-left' htmlFor="email">Email:</label>
        <input
          id="email"
          name="email"
          type="email"
          value={state.formData.email || ''}
          onChange={handleChange}
          className="text-sm rounded-lg block w-full p-2.5 dark:focus:ring-blue-500 order-solid border-2 border-sky-500"
          placeholder=""
        />
        {(state.formErrors.email || '') && <div className='text-left' style={{ color: 'red' }}>{(state.formErrors.email || '')}</div>}
        <br />

        <label className='text-xl text-gray-900 block mb-2 text-sm font-large text-gray-900 text-left' htmlFor="password">Password:</label>
        <input
          id="password"
          name="password"
          type="password"
          value={state.formData.password || ''}
          onChange={handleChange}
          className="text-sm rounded-lg block w-full p-2.5 dark:focus:ring-blue-500 order-solid border-2 border-sky-500"
          placeholder=""
        />
        {(state.formErrors.password || '') && <div className='text-left' style={{ color: 'red' }}>{(state.formErrors.password || '')}</div>}
        <br />

        <button type="submit" className="float-left text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Sign In</button>
      </form>
    </div>
  );
};

export default SignIn;

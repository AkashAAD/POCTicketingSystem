import { configureStore } from "@reduxjs/toolkit";
import ticketReducer from './Features/TicketSlice';
import userReducer from './Features/UserSlice';

const store = configureStore({
  reducer: {
    tickets: ticketReducer,
    users: userReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ['fetchTickets/fulfilled'],
        ignoredPaths: ['payload.headers'],
      }
    }
  )
});

export default store;

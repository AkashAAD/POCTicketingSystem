class TicketAssignment < ApplicationRecord
  belongs_to :ticket
  belongs_to :user

  validates :ticket_id, uniqueness: { scope: :user_id, message: "already assigned to this user" }
end
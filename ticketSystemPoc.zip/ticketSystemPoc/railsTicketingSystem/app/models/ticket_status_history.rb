class TicketStatusHistory < ApplicationRecord
  belongs_to :ticket
  belongs_to :user

  validates :status, presence: true

  enum :status, %i(open in_progress closed)
end

class ApplicationController < ActionController::API
  def not_found
    render json: { error: 'not_found' }
  end

  def authorize_request
    header = request.headers['HTTP_AUTHORIZATION']
    header = header.split(' ').last if header
    decoded = JsonWebToken.decode(header)
    Current.user = User.find(decoded[:user_id])
  rescue => e
    render json: { error: 'Please login with user.' }, status: :unauthorized
  end
end

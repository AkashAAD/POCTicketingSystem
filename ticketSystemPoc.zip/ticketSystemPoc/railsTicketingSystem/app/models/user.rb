class User < ApplicationRecord
  has_secure_password
  has_many :tickets
  has_many :ticket_assignments
  has_many :assigned_tickets, through: :ticket_assignments, source: :ticket
  has_many :ticket_comments

  validates :name, presence: true
  validates :email, presence: true, uniqueness: true, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :username, presence: true, uniqueness: true
  validates :password, length: { minimum: 6 }, if: -> { new_record? || !password.nil? }
end

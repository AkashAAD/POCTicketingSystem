class TicketService < TicketBaseService
  def initialize(params)
    @params = params
  end

  def create_ticket
    ticket = Ticket.new(ticket_params)
    ticket.user = Current.user

    if ticket.save
      ticket
    else
      raise ActiveRecord::RecordInvalid.new(ticket)
    end
  end

  def update_ticket
    ticket = ticket(@params[:id])
    if ticket.update(ticket_params)
      ticket
    else
      raise ActiveRecord::RecordInvalid.new(ticket)
    end
  end

  def assign_ticket(ticket, user)
    ticket_assignment = TicketAssignment.new(ticket: ticket, user: user)
    if ticket_assignment.save
      ticket_assignment
    else
      raise ActiveRecord::RecordInvalid.new(ticket_assignment)
    end
  end

  private

  def ticket_params
    @params.require(:ticket).permit(:title, :description, :priority)
  end
end

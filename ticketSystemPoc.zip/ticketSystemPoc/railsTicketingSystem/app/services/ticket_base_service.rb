class TicketBaseService
  def ticket(id)
    Ticket.find(id)
  end
end

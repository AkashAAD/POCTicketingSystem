import './App.css'
import AppRoutes from './AppRoutes';
import { ToastContainer } from "react-toastify";

function App() {
  // console.log(import.meta.env.VITE_API_URL);
  return (
    <>
      <AppRoutes/>
      <ToastContainer />
    </>
  )
}

export default App

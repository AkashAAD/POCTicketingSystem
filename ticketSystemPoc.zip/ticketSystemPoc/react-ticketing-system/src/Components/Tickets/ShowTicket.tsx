import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { stringFormat } from '../Utils';
import { viewTicket, selectTicket, selectStatus, selectError } from '../../Features/TicketSlice';


const ShowTicket = () => {
  const { id } = useParams();
  const dispatchTickets: any = useDispatch();
  const ticket = useSelector(selectTicket);
  const status = useSelector(selectStatus);
  const error = useSelector(selectError);

  useEffect(() => {
    dispatchTickets(viewTicket(id));
  }, []);

  return(
    <>
     <div className="justify-items-center h-screen overflow-x-auto container">
        <h3 className='text-4xl font-bold dark:text-black'>Your Ticket</h3>
        {status === 'loading' && <p>Loading...</p>}
        {error && <p>Error: {error}</p>}
        <ul>
          <li>Title: { ticket.title } </li>
          <li>Description: { ticket.description } </li>
          <li>Status: { stringFormat(ticket.status) } </li>
          <li>Priority: { stringFormat(ticket.priority) } </li>
        </ul>
      </div>
    </>
  )
}

export default ShowTicket;

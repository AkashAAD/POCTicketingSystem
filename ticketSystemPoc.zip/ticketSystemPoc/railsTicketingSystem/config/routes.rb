Rails.application.routes.draw do
  namespace :api do
    namespace :v1 do
      resources :tickets
      resources :ticket_comments, only: [:create]
      get 'ticket/:ticket_id/comments', to: 'ticket_comments#comments'
      resources :ticket_status_histories, only: [:index, :create]
      post '/user/login', to: 'authentication#sign_in'
    end
  end
end

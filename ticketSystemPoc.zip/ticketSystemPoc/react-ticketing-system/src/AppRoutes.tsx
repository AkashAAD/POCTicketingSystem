import { BrowserRouter, Routes, Route } from "react-router-dom";
import PrivateRoute from './Components/User/PrivateRoute';
import Header from "./Components/Layout/Header";
import Ticket from "./Components/Tickets/Ticket";
import Tickets from "./Components/Tickets/Tickets";
import ShowTicket from "./Components/Tickets/ShowTicket";
import Home from "./Components/Layout/Home";
import SignUp from "./Components/User/SignUp";
import SignIn from "./Components/User/SignIn";
import Page404 from "./Components/Layout/Page404";

const AppRoutes = () => {
return(
  <>
    <BrowserRouter>
      <Header/>
      <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/new/ticket" element={
              <PrivateRoute>
                <Ticket />
              </PrivateRoute>
            }
          />
          <Route path="/tickets" element={
              <PrivateRoute>
                <Tickets />
              </PrivateRoute>
            }
          />
          <Route path="/ticket/:id/show" element={
              <PrivateRoute>
                <ShowTicket />
              </PrivateRoute>
            }
          />
          <Route path="/ticket/:id/edit" element={
              <PrivateRoute>
                <Ticket />
              </PrivateRoute>
            }
          />
          <Route path="/sign-up" element={<SignUp />}/>
          <Route path="/sign-in" element={<SignIn />}/>
          <Route path="*" element={<Page404 />} />
      </Routes>
    </BrowserRouter>
  </>
)
};

export default AppRoutes;